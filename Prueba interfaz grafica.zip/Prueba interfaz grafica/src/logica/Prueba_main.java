
package logica;

import igu.Principal;

public class Prueba_main {
    public static void main(String[] args) {
        Principal pantalla = new Principal();
        pantalla.setVisible(true);
        pantalla.setLocationRelativeTo(null);        
    }
}
